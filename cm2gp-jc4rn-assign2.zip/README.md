# JCMDB
A conceptual website where the users have the power to add movie entries and leave movie review
